import 'package:flutter/material.dart';

void main() {
  runApp(const PetOrderApp());
}

class PetOrderApp extends StatelessWidget {
  const PetOrderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pet Order App',
      home: const HomePage(),
    );
  }
}

// 1. HOME PAGE
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pet Order - Home')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PetListPage()),
                );
              },
              child: const Text('Lihat Hewan Peliharaan'),
            )
          ],
        ),
      ),
    );
  }
}

// 2. PET LIST PAGE
class PetListPage extends StatelessWidget {
  const PetListPage({super.key});

  final List<String> pets = const [
    'Kucing Persia',
    'Anjing Husky',
    'Kelinci Mini',
    'Burung Lovebird',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daftar Hewan')), 
      body: ListView.builder(
        itemCount: pets.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(pets[index]),
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PetDetailPage(petName: pets[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// 3. PET DETAIL PAGE
class PetDetailPage extends StatelessWidget {
  final String petName;
  const PetDetailPage({super.key, required this.petName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(petName)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Detail: $petName', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => OrderPage(petName: petName),
                  ),
                );
              },
              child: const Text('Pesan Sekarang'),
            )
          ],
        ),
      ),
    );
  }
}

// 4. ORDER PAGE
class OrderPage extends StatefulWidget {
  final String petName;
  const OrderPage({super.key, required this.petName});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  final TextEditingController nameC = TextEditingController();
  final TextEditingController addressC = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Form Pemesanan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameC,
              decoration: const InputDecoration(labelText: 'Nama Pemesan'),
            ),
            TextField(
              controller: addressC,
              decoration: const InputDecoration(labelText: 'Alamat'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ReceiptPage(
                      petName: widget.petName,
                      customer: nameC.text,
                      address: addressC.text,
                    ),
                  ),
                );
              },
              child: const Text('Buat Struk'),
            )
          ],
        ),
      ),
    );
  }
}

// 5. RECEIPT PAGE (STRUK)
class ReceiptPage extends StatelessWidget {
  final String petName;
  final String customer;
  final String address;

  const ReceiptPage({super.key, required this.petName, required this.customer, required this.address});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Struk Pemesanan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('STRUK PEMBELIAN', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Text('Hewan: $petName'),
            Text('Nama Pemesan: $customer'),
            Text('Alamat: $address'),
            const SizedBox(height: 30),
            const Text('Terima kasih telah memesan!', style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}